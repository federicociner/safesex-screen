# Design Document


**Team**: *Team Cranky Euler*

## 1 Design Considerations


### 1.1 Assumptions


The purpose is to build a web-based tool that recommend screening for Chlamydia and Gonorrhea in a selection of patients. The app consists then of a doctor/provider facing portal with FHIR integraion that based on medical history for the patient and manual input about the patient can give insights or help decide whether or not they at increased risk of infection.  
For this we will use FHIR Api to interact with the database either by querying or modifying, we may add some backend logic to help determine if the patient is at risk of infection or not.  
The dependencies should be:
SQL, python, python-flask, javascript, react js

### 1.2 Constraints

The lack of formal medical experience
### 1.3 System Environment

Software: Chrome/Firefox browser Hardware: Not applicable in our case

## 2 Architectural Design


### 2.1 Component Diagram



![Component Diagram](https://i.ibb.co/HBXcSsj/Cranky-Euler-Component-Diagram.png)
### 2.2 Deployment Diagram

Based on the HDAP lecture:

![Deployment Diagram](https://i.ibb.co/pXm0t0y/deploy-diag.jpg)

## 3 Class Diagram


![Class Diagram](https://i.ibb.co/mTzT7ff/Cranky-Euler-Class-Diagram.png)

## 4 User Interface Design

These are very basic UI Design to get an idea on the things we may need to implement


![Clinician Login](https://i.ibb.co/PZV77wX/Clinician-Login-Page.png)

![Patient Data Capture](https://i.ibb.co/9tJW3ww/Patient-Data-Capture.png)

![Patient Profile](https://i.ibb.co/znvJV7M/Patient-Profile.png)

![Patient Recommendation](https://i.ibb.co/MG4Xc8s/Patient-Recommendation.png)



## 5 Research Overview
#### Overview
Chlamydia is a sexually transmitted disease caused by a bacteria called Chlamydia trachomatis. It is an infection that usually affects young, sexually active persons. Chlamydia trachomatis is a bacteria responsible for most sexually transmitted infections [1]. In most of the cases, the infection is asymptomatic which means it has no symptoms in fact 70% of women and 50% of men chlamydia produces few or no symptoms and remains undetected. Chlamydia can cause complications if not treated, especially in young women.

In Denmark the infection rate of chlamydia is about 456/100 000 in 2007. It is reported that around 10% of women and 13% of men aged under 25 years have chlamydia infection (1). In 2015 more than 1M chlamydia infection cases were reported in the US (2) Reported infection rates have increased in the last 10 years, this is due to the expansion of screening and better reporting systems (2).

  

Gonorrhea is also a sexually transmitted disease, it is caused by a bacteria called Neisseria gonorrhoeae. Just like chlamydia it is most common among young, aged under 25 years and sexually active persons. It can be asymptomatic, especially in women (2).

Gonorrhea is the second most common STD. in 2015 more than 1M cases of Gonorrhea infection were reported in the US (2).

  

Chlamydia and Gonorrhea can cause cervicitis, urethritis, proctitis, and pelvic inflammatory disease (PID). It is crucial to prevent and detect these infections early in order to protect and improve the sexual and individual health of patients and of the community. (2)

  

Patients infected with gonorrhea are more likely to be co-infected with chlamydia (3). It is recommended that a patient diagnosed with chlamydia or gonorrhea should consider screening for other STDs such as syphilis and HIV.

  

#### Tests and Screening

There has been major advancements in chlamydia and gonorrhea detection in the past 30 years, there are different diagnosis method but cell culture remains as a reference.

Repeated NAAT test ( Nucleic Acid Amplification Testing ) is the most sensitive test for chlamydia and gonorrhea (2)(1).

There are other available tests with different costs, specificity and sensitivity. Examples of those tests are Cell culture and Nucleic acid hybridization tests. (1) contains more details about various tests for chlamydia diagnosis.

  
In most cases Chlamydia and Gonorrhea infections are asymptomatic for both men and women. The United States Preventive Services Task Force and Centers for Disease Control and Prevention recommend screening for chlamydia every year for sexually active women aged under 25 years and for older women with risk factors or high risk sexual behaviours (2)(4). They do not recommend routine screening for men because of lack of evidence, efficiency and cost-effectivness, but still suggest targeted screening in heterosexual men with high sexual activity, men in correctional facilities, adolescent and STD’s clinics (2)(4).

Annual screening for gonorrhea is recommended for women aged under 25 years and for other women with increased risk factors (4). Those risk factors could be, having new or multiiple sex partners, not using protection, drug use, engaing in commercial sew work or living in communities with high disease prevelance.

Targeted screening is important for persons showing symptoms of chlamydia and gonorrhea or persons or children victim of sex abuse, or persons having intercourse with partners having STDs.

  

#### Screening Barriers

Majority of doctors do not follow the recommended routine screening for teenage and young women for various reasons. The physician belief, work environment, gender, opinion, ideology and commitment, influence his or her decision to proceed with chlamydia and gonorrhea screening or not (5). All these factors, along with the patient's lack of awareness can present barriers to the recommended screening.

#### Factors of higher risk of infection

In (2) Table 1 summarize some of History and Physical Examination Elements of Patients with Possible Chlamydia or Gonorrhea Infections, the following list summarizes the content of the table, these are the factors that can help determine the risk of infection:

-   Gender
    
-   Age under 25 and sexually active
    
-   Sexual contact with a person with an STD or STD related manifestation (symptoms)
    
-   Use of condoms
    
-   Number of sex partners in the past 60 days
    
-   New sex partners in the past 60 days
    
-   Environment with high STD diseases prevalence or not
    
-   Use of drugs
    
-   Exchange sex for drugs or money
    
-   Pain in joints or at sites of tendon insertions
    
-   Rash
    
-   Fever
    
-   Pharyngeal discomfort
    
-   Change in odor, amount, quality, color of vaginal discharge
    
-   Dysuria (painful or difficult urination)
    
-   Lower abdominal or pelvic pain
    
-   Pelvic pain with intercourse
    
-   Date of last menses
    
-   Pregnancy
    
-   Abnormal Intermenstrual bleeding
    
-   Urethral discharge, dysuria, testicular pain (for men)
    
-   Physical examination
    

-   Oral examination for lesions
    
-   Joint examination for tenderness and swelling
    
-   Rectal examination for mucosal friability, purulent discharge, perianal lesions
    
-   Inguinal, femoral, epitrochlear cervical nodes for swelling and/or tenderness
    
-   Pelvic speculum examination for vaginal pH, fluid characteristics, purulent discharge at the endocervix, cervical ectopy
    
-   Pelvic bimanual examination
    

The above mentioned factors can help decide whether or not to proceed with a screening for chlamydia and gonorrhea. Using this research overview, the above list and additional research if needed we will decide the factors that we will use in our application to determine whether or not to recommend a screening.

#### References
  

1.  Bébéar, C., & De Barbeyrac, B. (2009). Genital Chlamydia trachomatis infections. Clinical Microbiology and Infection, 15(1), 4-10.
    
2.  Workowski, K. (2013). Chlamydia and gonorrhea. Annals of internal medicine, 158(3), ITC2-1.
    
3.  Lyss, S. B., Kamb, M. L., Peterman, T. A., Moran, J. S., Newman, D. R., Bolan, G., ... & Ehret, J. (2003). Chlamydia trachomatis among patients infected with and treated for Neisseria gonorrhoeae in sexually transmitted disease clinics in the United States. Annals of internal medicine, 139(3), 178-185.
    
4.  Workowski, K. A., & Berman, S. M. (2011). Centers for Disease Control and Prevention sexually transmitted disease treatment guidelines. Clinical infectious diseases, 53(suppl_3), S59-S63.
    
5.  Cook, R. L., Wiesenfeld, H. C., Ashton, M. R., Krohn, M. A., Zamborsky, T., & Scholle, S. H. (2001). Barriers to screening sexually active adolescent women for chlamydia: a survey of primary care physicians. Journal of Adolescent Health, 28(3), 204-210.


## 6 Recommendation Logic and Pseudo Code
#### Logic
For our application, in order to determine whether or not a patient needs to have screening for Chlamydia or Gonorrhea. Based on the research summarized above we designed a recommendation logic that outputs 4 possible values which are no screening recommended, screening is optional, screening is highly recommended and screening is urgent. We used most of the factors mentioned above with different weights and priorities in order to determine the screening recommendation output.

We first consider whether or not the patient is sexually active, if not then no screening is recommended, then we check if the patient has certain combinations of symptoms which differ by gender, for example of the patient has dysuria and has fever or rush or both, or the patient has dysuria and pharyngeal discomfort and is female. The symptoms have high weights and importance in our recommendation system. So, if the patient is considered to have symptoms then it is urgent to do the screening no matter what are the other factors or patient details. Also, if the patient has recently had a sexual partner who had any STD or shows STD symptoms it is also urgent to do the screening.

The next most important factor to determine if the patient needs to have a screening is to see if the patient is a drug user, a sex worker or have exchanged sex for drugs or money and depending on the date of the latest screening it is either highly recommended or optional to do the screening, based on the research we did, STDs are common among drug users and sex workers. The above decision factors can be improved to output more accurate recommendation results if we add the environmental factor, which means if STDs are common in the community where the patient lives or not.

Also, the above logic concerns both males and females. In literature, screening is usually recommended for females and only males that shows symptoms or at very high risk of having Chlamydia or Gonorrhea or other STD. The remaining logic concerns only females. Most researchers recommend annual screening for sexually active women aged under 25, which we implemented in this logic, if a women is aged under 25 and didn’t have a screening in the past screening then it is highly recommended to do the screening in this case. The remaining logic treats the cases of relatively high risks but with lower priorities. Based on the number of sexual partners, the existence of new partners, the use of condoms and the date of the last screening the logic outputs if the patient does not need a screening, it is optional to the screening or highly recommended to do the screening treating different cases based on these factors.

#### Pseudo Code
```
If the patient is not sexually active:
	return "Screening is not recommended"
if the patient is aged under 15:
	return "Screening is not recommended"
If the patient is Female:
	if the patient has symptoms:
		return "Screening is Urgent"
	if the patient has sexual partner with STD or symptoms of STD:
		return "Screening is Urgent"
	if the patient is a sex worker or use drugs or may have exchanged sex for drugs:
		if the patient did not do screening for a year:
			return "Screening is Urgent"
		if the patient did not do screening in the past 3 months:
			return "Screening is Recommended"
		else:
			return "Screening is optional"	
	if the patient is aged under 25:
		if the patient did not do screening for a year:
			Screening is Highly Recommended
	if the patient has multiple sex patners:
		if the ptient has a new sex partner
			if the patient did not do screening in the past 3 months:
				if the pateint alwayse use protection:
					return "Screening is Optional"
				else:
					return "Screening is Highly Recommended"
			else:
				return "Screening is Optional"
		else:
			return "no screening is required"
	else:
		if the ptient has a new sex partner
			if the patient did not do screening in the past 3 months:
				if the patient.is_pregnant:
					return "Screening is Highly Recommended"
				else: 
					return "Screening is Optional"
	return "no screening is required"

if the patient is male:
	if the patient has symptoms:
		return "Screening is Urgent"
	if the patient has sexual partner with STD or symptoms of STD:
		return "Screening is Urgent"
	if the patient is a sex worker or use drugs or may have exchanged sex for drugs:
		if the patient did not do screening for a year:
			return "Screening is Highly Recommended"
		else: 
			return "Screening is Optional"
			
	return "no screening is required"
	  
```

## 7 Gaps in the Domain and industry problems
Although Screening is recommended by The United States Preventive Services Task Force and Centers for Disease Control and Prevention, many clinicians and patients do not adhere to these recommendations for many reasons, that can be related to the society the financial situation and doctor beliefs. From an industry perspective no other applications are specific to chlamydia and gonorrhea screening. It’s more of instructions available to help clinicians and patients decide whether or not to proceed with the screening. The lack of adherence to the instructions in many cases creates a gap in the screening programs overall. With an application that automatically recommends screening more clinicians and patients will adhere to the program and the risk of infection will probably be reduced while avoiding unnecessary screening and reducing the additional costs related to it.



